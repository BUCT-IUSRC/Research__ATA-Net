import os, sys

sys.path.insert(0, os.path.join(os.path.dirname(os.path.abspath(__file__)), '../'))
sys.path.insert(0, os.path.join(os.path.dirname(os.path.abspath(__file__)), '../lib/datasets'))
sys.path.insert(0, os.path.join(os.path.dirname(os.path.abspath(__file__)), '../lib/net'))
