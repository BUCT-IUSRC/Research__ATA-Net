import numpy as np
from scipy.spatial import Delaunay
import scipy
import lib.utils.object3d as object3d
import torch
import cv2


def get_objects_from_label(label_file):
    with open(label_file, 'r') as f:
        lines = f.readlines()
    objects = [object3d.Object3d(line) for line in lines]
    return objects


def dist_to_plane(plane, points):
    """
    Calculates the signed distance from a 3D plane to each point in a list of points
    :param plane: (a, b, c, d)
    :param points: (N, 3)
    :return: (N), signed distance of each point to the plane
    """
    a, b, c, d = plane

    points = np.array(points)
    x = points[:, 0]
    y = points[:, 1]
    z = points[:, 2]

    return (a * x + b * y + c * z + d) / np.sqrt(a ** 2 + b ** 2 + c ** 2)


def rotate_pc_along_y(pc, rot_angle):
    """
    params pc: (N, 3+C), (N, 3) is in the rectified camera coordinate
    params rot_angle: rad scalar
    Output pc: updated pc with XYZ rotated
    """
    cosval = np.cos(rot_angle)
    sinval = np.sin(rot_angle)
    rotmat = np.array([[cosval, -sinval], [sinval, cosval]])
    pc[:, [0, 2]] = np.dot(pc[:, [0, 2]], np.transpose(rotmat))
    return pc


def rotate_pc_along_y_torch(pc, rot_angle):
    """
    :param pc: (N, 512, 3 + C)
    :param rot_angle: (N)
    :return:
    TODO: merge with rotate_pc_along_y_torch in bbox_transform.py
    """
    cosa = torch.cos(rot_angle).view(-1, 1)  # (N, 1)
    sina = torch.sin(rot_angle).view(-1, 1)  # (N, 1)

    raw_1 = torch.cat([cosa, -sina], dim = 1)  # (N, 2)
    raw_2 = torch.cat([sina, cosa], dim = 1)  # (N, 2)
    R = torch.cat((raw_1.unsqueeze(dim = 1), raw_2.unsqueeze(dim = 1)), dim = 1)  # (N, 2, 2)

    pc_temp = pc[:, :, [0, 2]]  # (N, 512, 2)

    pc[:, :, [0, 2]] = torch.matmul(pc_temp, R.permute(0, 2, 1))  # (N, 512, 2)

    return pc


def boxes3d_to_corners3d(boxes3d, rotate = True):
    """
    :param boxes3d: (N, 7) [x, y, z, h, w, l, ry]
    :param rotate:
    :return: corners3d: (N, 8, 3)
    """
    boxes_num = boxes3d.shape[0]
    # print('boxes_num:', boxes_num)
    h, w, l = boxes3d[:, 3], boxes3d[:, 4], boxes3d[:, 5]
    x_corners = np.array([l / 2., l / 2., -l / 2., -l / 2., l / 2., l / 2., -l / 2., -l / 2.],
                         dtype = np.float32).T  # (N, 8)
    z_corners = np.array([w / 2., -w / 2., -w / 2., w / 2., w / 2., -w / 2., -w / 2., w / 2.],
                         dtype = np.float32).T  # (N, 8)

    y_corners = np.zeros((boxes_num, 8), dtype = np.float32)
    # y_corners[:, 4:8] = -h.reshape(boxes_num, 1).repeat(4, axis = 1)  # (N, 8)
    y_corners[:, 0:4] = (h / 2).reshape(boxes_num, 1).repeat(4, axis=1)
    y_corners[:, 4:8] = (-h / 2).reshape(boxes_num, 1).repeat(4, axis=1)
    one_corners = np.ones((boxes_num, 8), dtype = np.float32)

    if rotate:
        ry = boxes3d[:, 6]
        zeros, ones = np.zeros(ry.size, dtype = np.float32), np.ones(ry.size, dtype = np.float32)
        rot_list = np.array([[np.cos(ry), zeros, -np.sin(ry)],
                             [zeros, ones, zeros],
                             [np.sin(ry), zeros, np.cos(ry)]])  # (3, 3, N)
        R_list = np.transpose(rot_list, (2, 0, 1))  # (N, 3, 3)

        temp_corners = np.concatenate((x_corners.reshape(-1, 8, 1), y_corners.reshape(-1, 8, 1),
                                       z_corners.reshape(-1, 8, 1)), axis = 2)  # (N, 8, 3)
        rotated_corners = np.matmul(temp_corners, R_list)  # (N, 8, 3)
        x_corners, y_corners, z_corners = rotated_corners[:, :, 0], rotated_corners[:, :, 1], rotated_corners[:, :, 2]

    x_loc, y_loc, z_loc = boxes3d[:, 0], boxes3d[:, 1], boxes3d[:, 2]

    x = x_loc.reshape(-1, 1) + x_corners.reshape(-1, 8)
    y = y_loc.reshape(-1, 1) + y_corners.reshape(-1, 8)
    z = z_loc.reshape(-1, 1) + z_corners.reshape(-1, 8)

    corners = np.concatenate((x.reshape(-1, 8, 1), y.reshape(-1, 8, 1), z.reshape(-1, 8, 1)), axis=2)
    # corners = np.concatenate((x.reshape(-1, 8, 1), y.reshape(-1, 8, 1), z.reshape(-1, 8, 1), one_corners.reshape(-1, 8, 1)), axis = 2)
    # print('corners:', corners)
    # corners = np.hstack((corners, np.ones((corners.shape[0], 1), dtype=np.float32)))
    # B = np.array([[0.79857591, 0.60177011, 0.012217, 0.148042341],
    #               [0.2716508, -0.34223153, -0.89949064, 0.158559640],
    #               [0.53710554, 0.72163032, -0.43676919, 0.021031063]])
    # corners = np.dot(corners, np.transpose(B))
    # print('corners:', corners)
    # print('corners.astype(np.float32):', corners.astype(np.float32))

    return corners.astype(np.float32)
# def boxes3d_to_corners3d(boxes3d, rotate = True):
#     """
#     :param boxes3d: (N, 7) [x, y, z, h, w, l, ry]
#     :param rotate:
#     :return: corners3d: (N, 8, 3)
#     """
#     boxes_num = boxes3d.shape[0]
#     # print('boxes_num:', boxes_num)
#     h, w, l = boxes3d[:, 3], boxes3d[:, 4], boxes3d[:, 5]
#     x_corners = np.array([-w / 2., -w / 2., -w / 2., -w / 2., w / 2., w / 2., w / 2., w / 2.],
#                          dtype = np.float32).T  # (N, 8)
#     y_corners = np.array([-l / 2., -l / 2., l / 2., l / 2., -l / 2., -l / 2., l / 2., l / 2.],
#                          dtype = np.float32).T  # (N, 8)
#     z_corners = np.array([-h / 2., h / 2., h / 2., -h / 2., -h/ 2., h / 2., h / 2., -h / 2.],
#                          dtype = np.float32).T  # (N, 8)
#     # z_corners = np.zeros((boxes_num, 8), dtype = np.float32)
#     # # y_corners[:, 4:8] = -h.reshape(boxes_num, 1).repeat(4, axis = 1)  # (N, 8)
#     # y_corners[:, 0:4] = (h / 2).reshape(boxes_num, 1).repeat(4, axis=1)
#     # y_corners[:, 4:8] = (-h / 2).reshape(boxes_num, 1).repeat(4, axis=1)
#     one_corners = np.ones((boxes_num, 8), dtype = np.float32)
#
#     if rotate:
#         ry = boxes3d[:, 6]
#         zeros, ones = np.zeros(ry.size, dtype = np.float32), np.ones(ry.size, dtype = np.float32)
#         # rot_list = np.array([[np.cos(ry), zeros, -np.sin(ry)],
#         #                      [zeros, ones, zeros],
#         #                      [np.sin(ry), zeros, np.cos(ry)]])  # (3, 3, N)
#         rot_list = np.array([[-np.sin(ry), np.cos(ry), zeros],
#                              [np.cos(ry), np.sin(ry), zeros],
#                              [zeros, zeros, ones]])  # (3, 3, N)
#         R_list = np.transpose(rot_list, (2, 0, 1))  # (N, 3, 3)
#
#         temp_corners = np.concatenate((x_corners.reshape(-1, 8, 1), y_corners.reshape(-1, 8, 1),
#                                        z_corners.reshape(-1, 8, 1)), axis = 2)  # (N, 8, 3)
#         rotated_corners = np.matmul(temp_corners, R_list)  # (N, 8, 3)
#         x_corners, y_corners, z_corners = rotated_corners[:, :, 0], rotated_corners[:, :, 1], rotated_corners[:, :, 2]
#
#     x_loc, y_loc, z_loc = boxes3d[:, 0], boxes3d[:, 1], boxes3d[:, 2]
#
#     x = x_loc.reshape(-1, 1) + x_corners.reshape(-1, 8)
#     y = y_loc.reshape(-1, 1) + y_corners.reshape(-1, 8)
#     z = z_loc.reshape(-1, 1) + z_corners.reshape(-1, 8)
#
#     corners = np.concatenate((x.reshape(-1, 8, 1), y.reshape(-1, 8, 1), z.reshape(-1, 8, 1), one_corners.reshape(-1, 8, 1)), axis = 2)
#     # print('corners:', corners)
#     # corners = np.hstack((corners, np.ones((corners.shape[0], 1), dtype=np.float32)))
#     B = np.array([[0.79857591, 0.60177011, 0.012217, 0.148042341],
#                   [0.2716508, -0.34223153, -0.89949064, 0.158559640],
#                   [0.53710554, 0.72163032, -0.43676919, 0.021031063]])
#     corners = np.dot(corners, np.transpose(B))
#     # print('corners:', corners)
#     # print('corners.astype(np.float32):', corners.astype(np.float32))
#
#     return corners.astype(np.float32)

# def corners_nd(dims, origin=0.5):
#     ndim = int(dims.shape[1])
#     corners_norm = np.stack(
#         np.unravel_index(np.arange(2 ** ndim), [2] * ndim),#返回该数组中每个元素（即flattern索引值）对应的原数组的索引
#         axis=1).astype(dims.dtype)#[8,3]
#
#     if ndim == 2:
#         # generate clockwise box corners
#         corners_norm = corners_norm[[0, 1, 3, 2]]
#     elif ndim == 3:
#         corners_norm = corners_norm[[0, 1, 3, 2, 4, 5, 7, 6]]
#     corners_norm = corners_norm - np.array(origin, dtype=dims.dtype)
#     corners = dims.reshape([-1, 1, ndim]) * corners_norm.reshape(
#         [1, 2 ** ndim, ndim])
#     return corners#[1,8,3]
#
# def rotation_3d_in_axis(points, angles, axis=0):
#     # points: [N, point_size, 3]
#     rot_sin = np.sin(angles)
#     rot_cos = np.cos(angles)
#     ones = np.ones_like(rot_cos)
#     zeros = np.zeros_like(rot_cos)
#     if axis == 1:
#         rot_mat_T = np.stack([[rot_cos, zeros, -rot_sin], [zeros, ones, zeros],
#                               [rot_sin, zeros, rot_cos]])
#     elif axis == 2 or axis == -1:
#         rot_mat_T = np.stack([[rot_cos, -rot_sin, zeros],
#                               [rot_sin, rot_cos, zeros], [zeros, zeros, ones]])
#     elif axis == 0:
#         rot_mat_T = np.stack([[zeros, rot_cos, -rot_sin],
#                               [zeros, rot_sin, rot_cos], [ones, zeros, zeros]])
#     else:
#         raise ValueError("axis should in range")
#
#     return np.einsum('aij,jka->aik', points, rot_mat_T)
#
# def center_to_corner_box3d_(bbox,origin=(0.5, 0.5, 0.5), axis=2):
#     # pdb.set_trace()
#     centers = bbox[:, :3]#中心点 x,y,z [ -3.94672347, -62.38768339,  -3.1443063 ]
#     dims = bbox[:, 3:6]#宽、长、高 [0.74305974, 1.5765898 , 1.57541666]
#     angles = 3/2 * np.pi - bbox[:, 6]#角度 3/2×pi [4.68024822]
#     corners = corners_nd(dims, origin=origin)
#     if angles is not None:
#         corners = rotation_3d_in_axis(corners, angles, axis=axis)
#     corners += centers.reshape([-1, 1, 3])
#     return corners
#
#
# class Map(object):
#     def __init__(self):
#         #上地西路
#         self.in_param = np.mat([[8.378488769500e+02, 0.000000000000e+00, 9.661206550200e+02], [0.000000000000e+00, 8.360205078100e+02, 5.487469895300e+02], [0.0, 0.0, 1.0]])#相机内参
#         self.rotate_vec = np.mat([1.93723823, 0.65643999, -0.39449230])#旋转向量
#         self.translation_vec = np.mat([0.148042341, 0.15855964, 0.021031063]) #平移向量
#         self.dist_vec = np.mat([-0.3269, 0.09717, 0.000718, 0.000659, 0])#畸变参数
#         # self.in_param = np.mat([[1158.52, 0, 964.76], [0, 1153.0, 545.86], [0.0, 0.0, 1.0]])#相机内参
#         # self.rotate_vec = np.mat([1.9372382311618077, 0.6564399979100769, -0.39449230193351015])#旋转向量
#         # self.translation_vec = np.mat([148.042341, 158.559640, 21.031063]) / 1000#平移向量
#         # self.dist_vec = np.mat([-0.3269, 0.09717, 0.000718, 0.000659, 0])#畸变参数
#         self.get_tf_lidar_to_cam()
#
#     def get_tf_lidar_to_cam(self):
#         tf_lidar_to_cam = np.zeros((4, 4))
#         self.rotate_mat, _ = cv2.Rodrigues(self.rotate_vec)#旋转向量和旋转矩阵的互相转换
#         tf_lidar_to_cam[:3, :3] = self.rotate_mat
#         tf_lidar_to_cam[:3, 3] = self.translation_vec
#         tf_lidar_to_cam[3, 3] = 1
#         self.tf_lidar_to_cam = tf_lidar_to_cam#4×4
#
#     def lidar_to_cam(self, xyz_lidar):
#         xyz_lidar = xyz_lidar
#         xyz_lidar = np.hstack([xyz_lidar, np.ones(xyz_lidar.shape[0]).reshape(-1, 1)])
#         return self.tf_lidar_to_cam.dot(xyz_lidar.T)[:3].T
#
#
# def boxes3d_to_corners3d(boxes3d, rotate = True):
#     """
#     :param boxes3d: (N, 7) [x, y, z, h, w, l, ry]
#     :param rotate:
#     :return: corners3d: (N, 8, 3)
#     """
#     lidar_data = []
#     x = list(boxes3d)
#     for j in range(len(x)):
#         boxes3d = x[j]
#         arr_ = [float(boxes3d[0]),
#                 float(boxes3d[1]),
#                 float(boxes3d[2]),
#                 float(boxes3d[4]),  # 宽
#                 float(boxes3d[5]),  # 长
#                 float(boxes3d[3]),  # 高
#                 float(boxes3d[6])
#                 ]
#         lidar_data.append(arr_)
#
#     map_ = Map()
#     # 计算8个角点
#     lidar_data = np.array(lidar_data)
#     # print('lidar_data:', lidar_data)
#     if rotate:
#         boxes_corners = center_to_corner_box3d_(lidar_data)
#         # print('boxes_corners:', boxes_corners)
#         boxes_corners1 = []
#         for po in range(boxes_corners.shape[0]):
#             lidar_data = boxes_corners[po]
#             xyz_cam = map_.lidar_to_cam(lidar_data)
#             filter_cam = np.where(xyz_cam[:, 2] > 0, True, False)
#             # print('filter_cam:', filter_cam)
#             lidar_data = np.mat(lidar_data)
#             # print('lidar_data1:', lidar_data)
#             # # 给定的内参数和外参数计算三维点投影到二维图像平面上的坐标
#             # # point_2d, _ = cv2.projectPoints(np.array(lidar_data), np.array(map_.rotate_vec),
#             # #                                 np.array(map_.translation_vec), np.array(map_.in_param),
#             # #                                 np.array(map_.dist_vec))
#             # point_3d, _ = cv2.projectPoints(np.array(lidar_data), np.array(map_.rotate_vec),
#             #                                 np.array(map_.translation_vec), np.array(map_.in_param),
#             #                                 distCoeffs=None)
#             # point_3d = np.squeeze(point_3d)  # 320,2
#             # print('point_2d:', point_3d)
#             lidar_data = np.array(lidar_data)
#             lidar_data = np.hstack((lidar_data, np.ones((lidar_data.shape[0], 1), dtype=np.float32)))
#             B = np.array([[0.79857591, 0.60177011, 0.012217, 0.148042341],
#                           [0.2716508, -0.34223153, -0.89949064, 0.158559640],
#                           [0.53710554, 0.72163032, -0.43676919, 0.021031063]])
#             lidar_data = np.dot(lidar_data, np.transpose(B))
#             boxes_corners1.append(lidar_data.astype(np.float32))
#
#             # point_draw = []
#             # for i in range(lidar_data.shape[0]):
#             #
#             #     r = np.sqrt(lidar_data[i, 0] ** 2 + lidar_data[i, 1] ** 2)
#             #     height = lidar_data[i, 2]
#             #     if filter_cam[i] == False:
#             #         continue
#             #     # if height < -4.0: #过滤地面
#             #     #     continue
#             #     # if r > 50:#过滤距离
#             #     #     continue
#             #     print('point_2d[i, 0]:',point_3d[i, 0])
#             #     print('point_2d[i, 1]:', point_3d[i, 1])
#             #     if point_3d[i, 0] < 1920 and point_3d[i, 0] > 0 and point_3d[i, 1] < 1080 and point_3d[i, 1] > 0:
#             #         # cv2.circle(img, (int(point_2d[i, 0]), int(point_2d[i, 1])), 1, (0, 0, 255), thickness=2)
#             #         point_draw.append(point_3d[i]/100)
#             #         print('point_draw:', point_draw)
#     # print('lidar_data:', lidar_data)
#     # print('boxes_corners1:', boxes_corners1)
#     return boxes_corners1


def boxes3d_to_corners3d_torch(boxes3d, flip = False):
    """
    :param boxes3d: (N, 7) [x, y, z, h, w, l, ry]
    :return: corners_rotated: (N, 8, 3)
    """
    boxes_num = boxes3d.shape[0]
    h, w, l, ry = boxes3d[:, 3:4], boxes3d[:, 4:5], boxes3d[:, 5:6], boxes3d[:, 6:7]
    if flip:
        ry = ry + np.pi
    centers = boxes3d[:, 0:3]
    zeros = torch.cuda.FloatTensor(boxes_num, 1).fill_(0)
    ones = torch.cuda.FloatTensor(boxes_num, 1).fill_(1)

    x_corners = torch.cat([l / 2., l / 2., -l / 2., -l / 2., l / 2., l / 2., -l / 2., -l / 2.], dim = 1)  # (N, 8)
    y_corners = torch.cat([zeros, zeros, zeros, zeros, -h, -h, -h, -h], dim = 1)  # (N, 8)
    z_corners = torch.cat([w / 2., -w / 2., -w / 2., w / 2., w / 2., -w / 2., -w / 2., w / 2.], dim = 1)  # (N, 8)
    corners = torch.cat((x_corners.unsqueeze(dim = 1), y_corners.unsqueeze(dim = 1), z_corners.unsqueeze(dim = 1)),
                        dim = 1)  # (N, 3, 8)

    cosa, sina = torch.cos(ry), torch.sin(ry)
    raw_1 = torch.cat([cosa, zeros, sina], dim = 1)
    raw_2 = torch.cat([zeros, ones, zeros], dim = 1)
    raw_3 = torch.cat([-sina, zeros, cosa], dim = 1)
    R = torch.cat((raw_1.unsqueeze(dim = 1), raw_2.unsqueeze(dim = 1), raw_3.unsqueeze(dim = 1)), dim = 1)  # (N, 3, 3)

    corners_rotated = torch.matmul(R, corners)  # (N, 3, 8)
    corners_rotated = corners_rotated + centers.unsqueeze(dim = 2).expand(-1, -1, 8)
    corners_rotated = corners_rotated.permute(0, 2, 1)
    return corners_rotated


def boxes3d_to_bev_torch(boxes3d):
    """
    :param boxes3d: (N, 7) [x, y, z, h, w, l, ry]
    :return:
        boxes_bev: (N, 5) [x1, y1, x2, y2, ry]
    """
    boxes_bev = boxes3d.new(torch.Size((boxes3d.shape[0], 5)))

    cu, cv = boxes3d[:, 0], boxes3d[:, 2]
    half_l, half_w = boxes3d[:, 5] / 2, boxes3d[:, 4] / 2
    boxes_bev[:, 0], boxes_bev[:, 1] = cu - half_l, cv - half_w
    boxes_bev[:, 2], boxes_bev[:, 3] = cu + half_l, cv + half_w
    boxes_bev[:, 4] = boxes3d[:, 6]
    return boxes_bev


def enlarge_box3d(boxes3d, extra_width):
    """
    :param boxes3d: (N, 7) [x, y, z, h, w, l, ry]
    """
    if isinstance(boxes3d, np.ndarray):
        large_boxes3d = boxes3d.copy()
    else:
        large_boxes3d = boxes3d.clone()
    large_boxes3d[:, 3:6] += extra_width * 2
    large_boxes3d[:, 1] += extra_width
    return large_boxes3d


def in_hull(p, hull):
    """
    :param p: (N, K) test points
    :param hull: (M, K) M corners of a box
    :return (N) bool
    """
    try:
        # print('1:',1)
        if not isinstance(hull, Delaunay):
            hull = Delaunay(hull)
        flag = hull.find_simplex(p) >= 0
    except scipy.spatial.qhull.QhullError:
        # print('2:', 2)
        print('Warning: not a hull %s' % str(hull))
        flag = np.zeros(p.shape[0], dtype = np.bool)

    return flag


def objs_to_boxes3d(obj_list):
    boxes3d = np.zeros((obj_list.__len__(), 7), dtype = np.float32)
    for k, obj in enumerate(obj_list):
        boxes3d[k, 0:3], boxes3d[k, 3], boxes3d[k, 4], boxes3d[k, 5], boxes3d[k, 6] \
            = obj.pos, obj.h, obj.w, obj.l, obj.ry
    return boxes3d


def objs_to_scores(obj_list):
    scores = np.zeros((obj_list.__len__()), dtype = np.float32)
    for k, obj in enumerate(obj_list):
        scores[k] = obj.score
    return scores


def get_iou3d(corners3d, query_corners3d, need_bev = False):
    """	
    :param corners3d: (N, 8, 3) in rect coords	
    :param query_corners3d: (M, 8, 3)	
    :return:	
    """
    from shapely.geometry import Polygon
    A, B = corners3d, query_corners3d
    N, M = A.shape[0], B.shape[0]
    iou3d = np.zeros((N, M), dtype = np.float32)
    iou_bev = np.zeros((N, M), dtype = np.float32)

    # for height overlap, since y face down, use the negative y
    min_h_a = -A[:, 0:4, 1].sum(axis = 1) / 4.0
    max_h_a = -A[:, 4:8, 1].sum(axis = 1) / 4.0
    min_h_b = -B[:, 0:4, 1].sum(axis = 1) / 4.0
    max_h_b = -B[:, 4:8, 1].sum(axis = 1) / 4.0

    for i in range(N):
        for j in range(M):
            max_of_min = np.max([min_h_a[i], min_h_b[j]])
            min_of_max = np.min([max_h_a[i], max_h_b[j]])
            h_overlap = np.max([0, min_of_max - max_of_min])
            if h_overlap == 0:
                continue

            bottom_a, bottom_b = Polygon(A[i, 0:4, [0, 2]].T), Polygon(B[j, 0:4, [0, 2]].T)
            if bottom_a.is_valid and bottom_b.is_valid:
                # check is valid,  A valid Polygon may not possess any overlapping exterior or interior rings.
                bottom_overlap = bottom_a.intersection(bottom_b).area
            else:
                bottom_overlap = 0.
            overlap3d = bottom_overlap * h_overlap
            union3d = bottom_a.area * (max_h_a[i] - min_h_a[i]) + bottom_b.area * (max_h_b[j] - min_h_b[j]) - overlap3d
            iou3d[i][j] = overlap3d / union3d
            iou_bev[i][j] = bottom_overlap / (bottom_a.area + bottom_b.area - bottom_overlap)

    if need_bev:
        return iou3d, iou_bev

    return iou3d
