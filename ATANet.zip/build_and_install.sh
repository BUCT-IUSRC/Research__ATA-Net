cd pointnet2_lib/pointnet2
python setup.py install
cd ../../

cd lib/utils/iou3d/
python setup.py install

cd ../roipool3d/
python setup.py install

cd ../../../tools
